import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/App';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [location] = useLocation();
  const auth = useAuth();
  
  const isHomePage = location === '/';
  
  // Handle scroll effect
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    
    if (isHomePage) {
      window.addEventListener('scroll', handleScroll);
      return () => window.removeEventListener('scroll', handleScroll);
    } else {
      // Always use solid background on other pages
      setIsScrolled(true);
    }
  }, [isHomePage]);
  
  // Smooth scroll to section (only on homepage)
  const scrollToSection = (id: string) => {
    if (isHomePage) {
      const element = document.getElementById(id);
      
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
        setIsMobileMenuOpen(false);
      }
    }
  };
  
  // Toggle mobile menu
  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };
  
  return (
    <nav 
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled || !isHomePage
          ? 'bg-white text-gray-900 shadow-md py-2' 
          : 'bg-transparent text-white py-4'
      }`}
    >
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="font-bold text-xl md:text-2xl cursor-pointer">
            Ali Your Barber
          </Link>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-6">
            {isHomePage ? (
              <>
                <a 
                  href="#services" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('services');
                  }}
                >
                  Services
                </a>
                <a 
                  href="#hours" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('hours');
                  }}
                >
                  Hours
                </a>
                <a 
                  href="#location" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('location');
                  }}
                >
                  Location
                </a>
                <a 
                  href="#contact" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('contact');
                  }}
                >
                  Contact
                </a>
                <Button
                  onClick={() => scrollToSection('appointments')}
                  className={isScrolled ? '' : 'bg-white text-gray-900 hover:bg-gray-100'}
                >
                  Book Now
                </Button>
              </>
            ) : (
              <Link href="/" className="hover:text-primary transition-colors">
                Home
              </Link>
            )}
            
            {auth.isAuthenticated ? (
              <>
                <Link href="/dashboard" className="hover:text-primary transition-colors">
                  My Appointments
                </Link>
                <Button variant="outline" onClick={auth.logout}>
                  Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link href="/login" className="hover:text-primary transition-colors">
                  Sign In
                </Link>
                <Link href="/register">
                  <Button>Register</Button>
                </Link>
              </>
            )}
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button
              onClick={toggleMobileMenu}
              className={`p-2 focus:outline-none ${
                isScrolled || !isHomePage ? 'text-gray-900' : 'text-white'
              }`}
            >
              <svg 
                xmlns="http://www.w3.org/2000/svg" 
                className="h-6 w-6" 
                fill="none" 
                viewBox="0 0 24 24" 
                stroke="currentColor"
              >
                <path 
                  strokeLinecap="round" 
                  strokeLinejoin="round" 
                  strokeWidth={2} 
                  d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} 
                />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden pt-4 pb-2 space-y-2">
            {isHomePage ? (
              <>
                <a 
                  href="#services" 
                  className="block py-2 hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('services');
                  }}
                >
                  Services
                </a>
                <a 
                  href="#hours" 
                  className="block py-2 hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('hours');
                  }}
                >
                  Hours
                </a>
                <a 
                  href="#location" 
                  className="block py-2 hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('location');
                  }}
                >
                  Location
                </a>
                <a 
                  href="#contact" 
                  className="block py-2 hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    scrollToSection('contact');
                  }}
                >
                  Contact
                </a>
                <Button
                  onClick={() => scrollToSection('appointments')}
                  className="w-full mt-2"
                >
                  Book Now
                </Button>
              </>
            ) : (
              <Link href="/" className="block py-2 hover:text-primary transition-colors">
                Home
              </Link>
            )}
            
            {auth.isAuthenticated ? (
              <>
                <Link href="/dashboard" className="block py-2 hover:text-primary transition-colors">
                  My Appointments
                </Link>
                <Button variant="outline" onClick={auth.logout} className="w-full mt-2">
                  Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link href="/login" className="block py-2 hover:text-primary transition-colors">
                  Sign In
                </Link>
                <Link href="/register" className="block">
                  <Button className="w-full mt-2">Register</Button>
                </Link>
              </>
            )}
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;