import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Business Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">Ali Your Barber</h3>
            <p className="mb-2">Professional Hair and Beard Styling</p>
            <p className="mb-1">Bahnhofstrasse, 8001 Zürich</p>
            <p className="mb-1">Switzerland</p>
            <p className="mb-1">+41 76 123 45 67</p>
            <p>info@aliyourbarber.ch</p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a 
                  href="#services" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    const element = document.getElementById('services');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Services
                </a>
              </li>
              <li>
                <a 
                  href="#appointments" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    const element = document.getElementById('appointments');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Book Appointment
                </a>
              </li>
              <li>
                <a 
                  href="#hours" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    const element = document.getElementById('hours');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Business Hours
                </a>
              </li>
              <li>
                <a 
                  href="#contact" 
                  className="hover:text-primary transition-colors"
                  onClick={(e) => {
                    e.preventDefault();
                    const element = document.getElementById('contact');
                    if (element) element.scrollIntoView({ behavior: 'smooth' });
                  }}
                >
                  Contact Us
                </a>
              </li>
            </ul>
          </div>
          
          {/* Business Hours Summary */}
          <div>
            <h3 className="text-xl font-bold mb-4">Business Hours</h3>
            <p className="mb-1">Monday - Friday: 9:00 AM - 6:30 PM</p>
            <p className="mb-1">Saturday: 9:00 AM - 5:00 PM</p>
            <p className="mb-4">Sunday: Closed</p>
            <p className="text-sm">We are closed on public holidays.</p>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p>&copy; {new Date().getFullYear()} Ali Your Barber. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;