import React from 'react';
import { useTranslation } from '@/lib/TranslationContext';

interface DayHoursProps {
  day: string;
  hours: string;
  isOpen: boolean;
}

const businessHours: DayHoursProps[] = [
  { day: 'Monday', hours: '9:00 AM - 6:30 PM', isOpen: true },
  { day: 'Tuesday', hours: '9:00 AM - 6:30 PM', isOpen: true },
  { day: 'Wednesday', hours: '9:00 AM - 6:30 PM', isOpen: true },
  { day: 'Thursday', hours: '9:00 AM - 6:30 PM', isOpen: true },
  { day: 'Friday', hours: '9:00 AM - 6:30 PM', isOpen: true },
  { day: 'Saturday', hours: '9:00 AM - 5:00 PM', isOpen: true },
  { day: 'Sunday', hours: 'Closed', isOpen: false },
];

const DayHours: React.FC<DayHoursProps> = ({ day, hours, isOpen }) => {
  const { t, currentLanguage } = useTranslation();
  
  // Get the current day in English and check if the current day name matches the displayed day
  const today = new Date().getDay(); // 0 = Sunday, 1 = Monday, etc.
  const weekdays = [
    t('hours.sunday'),
    t('hours.monday'),
    t('hours.tuesday'),
    t('hours.wednesday'),
    t('hours.thursday'),
    t('hours.friday'),
    t('hours.saturday')
  ];
  
  const isToday = weekdays[today] === day;
  
  return (
    <div className={`flex justify-between py-2 border-b ${isToday ? 'font-bold' : ''}`}>
      <div className="flex items-center">
        {isToday && <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>}
        <span>{day}</span>
      </div>
      <div className={isOpen ? 'text-green-600' : 'text-red-500'}>
        {hours}
      </div>
    </div>
  );
};

const BusinessHours: React.FC = () => {
  const { t } = useTranslation();
  
  // Define translated business hours
  const translatedBusinessHours: DayHoursProps[] = [
    { day: t('hours.monday'), hours: '9:00 AM - 6:30 PM', isOpen: true },
    { day: t('hours.tuesday'), hours: '9:00 AM - 6:30 PM', isOpen: true },
    { day: t('hours.wednesday'), hours: '9:00 AM - 6:30 PM', isOpen: true },
    { day: t('hours.thursday'), hours: '9:00 AM - 6:30 PM', isOpen: true },
    { day: t('hours.friday'), hours: '9:00 AM - 6:30 PM', isOpen: true },
    { day: t('hours.saturday'), hours: '9:00 AM - 5:00 PM', isOpen: true },
    { day: t('hours.sunday'), hours: t('hours.closed'), isOpen: false },
  ];
  
  return (
    <section id="hours" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">{t('hours.title')}</h2>
            <p className="text-gray-600">
              {t('hours.subtitle')}
            </p>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            {translatedBusinessHours.map((dayInfo, index) => (
              <DayHours key={index} {...dayInfo} />
            ))}
            
            <div className="mt-6 text-center text-sm text-gray-500">
              <p>{t('hours.holidayNotice')}</p>
              <p className="mt-2">{t('hours.specialAppointments')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BusinessHours;