import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';

interface ServiceOption {
  id: string;
  name: string;
  price: number;
  duration: string;
}

const QuickBookModal = () => {
  const [selectedService, setSelectedService] = useState<string | undefined>(undefined);
  const [isOpen, setIsOpen] = useState(false);

  const services: ServiceOption[] = [
    { id: 'cut_go', name: 'Cut & Go', price: 30, duration: '30 min' },
    { id: 'beard', name: 'Beard', price: 25, duration: '20 min' },
    { id: 'kids', name: 'Kinder (Kids)', price: 20, duration: '20 min' },
  ];

  const handleServiceChange = (value: string) => {
    setSelectedService(value);
  };

  const handleBookNow = () => {
    if (!selectedService) return;
    
    // Get the selected service
    const service = services.find(s => s.id === selectedService);
    if (!service) return;
    
    // Get Calendly URL from environment variables
    const CALENDLY_URL = import.meta.env.VITE_CALENDLY_URL;
    if (!CALENDLY_URL) {
      console.error('Calendly URL not configured');
      return;
    }
    
    // Create the Calendly URL with the service as a parameter
    const url = new URL(CALENDLY_URL);
    url.searchParams.append('custom_question', 'Service Type');
    url.searchParams.append('custom_answer', service.name);
    
    // Open Calendly in a new tab
    window.open(url.toString(), '_blank', 'noopener,noreferrer');
    
    // Close the modal
    setIsOpen(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <div className="fixed bottom-6 right-6 z-50">
          <Button 
            className="rounded-full h-16 w-16 shadow-lg flex items-center justify-center p-0 bg-primary text-white hover:bg-primary/90"
            onClick={() => setIsOpen(true)}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
          </Button>
          <div className="absolute -top-10 right-0 bg-white rounded-lg shadow-md px-3 py-2 text-sm font-medium text-center min-w-[100px]">
            Quick Book
            <div className="absolute bottom-[-6px] right-[28px] w-3 h-3 bg-white transform rotate-45"></div>
          </div>
        </div>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] rounded-lg">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">Quick Appointment</DialogTitle>
        </DialogHeader>
        <div className="p-6 space-y-6">
          <div>
            <h3 className="font-medium mb-2">Select your service:</h3>
            <div className="grid grid-cols-1 gap-3">
              {services.map((service) => (
                <div 
                  key={service.id} 
                  className={`p-3 border rounded-lg cursor-pointer transition-all duration-300 ${
                    selectedService === service.id 
                      ? 'border-primary bg-primary/5 shadow-md translate-y-[-2px]' 
                      : 'border-gray-200 hover:border-gray-300 hover:shadow-sm hover:translate-y-[-1px]'
                  }`}
                  onClick={() => handleServiceChange(service.id)}
                >
                  <div className="flex justify-between items-center">
                    <div>
                      <span className={`font-medium block transition-colors duration-300 ${
                        selectedService === service.id ? 'text-primary' : 'group-hover:text-primary'
                      }`}>{service.name}</span>
                      <span className="text-sm text-gray-500">{service.duration}</span>
                    </div>
                    <div className="text-right">
                      <span className={`font-bold transition-all duration-300 ${
                        selectedService === service.id ? 'text-primary scale-110' : ''
                      }`}>{service.price} CHF</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <Button 
            className={`w-full py-6 text-lg transition-all duration-300 ${
              selectedService 
                ? 'hover:scale-[1.02] hover:shadow-md' 
                : 'opacity-70'
            }`}
            onClick={handleBookNow}
            disabled={!selectedService}
          >
            {selectedService ? (
              <span className="flex items-center justify-center">
                Book Appointment
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-5 w-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                </svg>
              </span>
            ) : 'Select a Service'}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default QuickBookModal;