import React from 'react';
import { Button } from '@/components/ui/button';
import { useTranslation } from '@/lib/TranslationContext';

const Hero: React.FC = () => {
  const { t } = useTranslation();
  
  const scrollToAppointments = () => {
    const appointmentsSection = document.getElementById('appointments');
    if (appointmentsSection) {
      appointmentsSection.scrollIntoView({ behavior: 'smooth' });
    }
  };
  
  return (
    <section className="relative bg-gray-900 text-white">
      {/* Hero background with overlay */}
      <div className="absolute inset-0 bg-gradient-to-r from-black to-transparent opacity-70"></div>
      <div
        className="absolute inset-0 z-0 bg-cover bg-center"
        style={{ 
          backgroundImage: `url('https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1200&q=80')` 
        }}
      ></div>
      
      {/* Hero content */}
      <div className="container mx-auto px-4 py-24 md:py-32 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            {t('hero.title')}
          </h1>
          <p className="text-xl mb-6 text-gray-200">
            {t('hero.subtitle')}
          </p>
          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              onClick={scrollToAppointments}
              size="lg"
              className="px-6 py-3 text-lg font-semibold"
            >
              {t('hero.bookAppointment')}
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="px-6 py-3 text-lg font-semibold text-white border-white hover:bg-white/10"
              onClick={() => {
                const servicesSection = document.getElementById('services');
                if (servicesSection) {
                  servicesSection.scrollIntoView({ behavior: 'smooth' });
                }
              }}
            >
              {t('hero.ourServices')}
            </Button>
          </div>
          
          {/* Quick info */}
          <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-6 text-center sm:text-left">
            <div>
              <h3 className="text-lg font-semibold mb-1">{t('hero.expertStylists')}</h3>
              <p className="text-gray-300">{t('hero.expertStylistsDesc')}</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-1">{t('hero.premiumCare')}</h3>
              <p className="text-gray-300">{t('hero.premiumCareDesc')}</p>
            </div>
            <div>
              <h3 className="text-lg font-semibold mb-1">{t('hero.easyBooking')}</h3>
              <p className="text-gray-300">{t('hero.easyBookingDesc')}</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;