import React from 'react';
import { useTranslation } from '@/lib/TranslationContext';

interface ServiceProps {
  title: string;
  description: string;
  price: number;
  duration: string;
  image: string;
  alt: string;
}

// Services will be defined within the component function

const ServiceCard = ({ title, description, price, duration, image, alt }: ServiceProps) => {
  const { t } = useTranslation();
  
  // Get Calendly URL
  const CALENDLY_URL = import.meta.env.VITE_CALENDLY_URL || '';
  
  // Create a direct link to Calendly with service name
  const getCalendlyLink = () => {
    if (!CALENDLY_URL) {
      // If no Calendly URL, scroll to appointments section
      return () => {
        const appointmentsSection = document.getElementById('appointments');
        if (appointmentsSection) {
          appointmentsSection.scrollIntoView({ behavior: 'smooth' });
        }
      };
    }
    
    // Otherwise, return the direct Calendly URL
    const url = new URL(CALENDLY_URL);
    url.searchParams.append('custom_question', 'Service Type');
    url.searchParams.append('custom_answer', title);
    return url.toString();
  };
  
  const link = getCalendlyLink();
  
  return (
    <div className="rounded-lg overflow-hidden shadow-md bg-white transition-all duration-300 hover:shadow-xl hover:-translate-y-1 group">
      <div className="h-48 overflow-hidden">
        <img 
          src={image} 
          alt={alt} 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
      </div>
      <div className="p-5 relative z-10 transition-colors duration-300 group-hover:bg-gray-50">
        <div className="flex justify-between items-start mb-2">
          <h3 className="text-xl font-bold transition-colors duration-300 group-hover:text-primary">{title}</h3>
          <div className="flex flex-col items-end">
            <span className="font-bold text-lg transition-all duration-300 group-hover:scale-110 group-hover:text-primary">{price} CHF</span>
            <span className="text-sm text-gray-500">{duration}</span>
          </div>
        </div>
        <p className="text-gray-700">{description}</p>
        
        {typeof link === 'string' ? (
          <a 
            href={link}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-4 text-primary font-medium group-hover:underline flex items-center transition-transform duration-300 group-hover:translate-x-1"
          >
            {t('services.bookService')}
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </a>
        ) : (
          <button 
            className="mt-4 text-primary font-medium group-hover:underline flex items-center transition-transform duration-300 group-hover:translate-x-1"
            onClick={link}
          >
            {t('services.bookService')}
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-1 transition-transform duration-300 group-hover:translate-x-1" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </button>
        )}
      </div>
    </div>
  );
};

const Services: React.FC = () => {
  const { t } = useTranslation();
  
  // Define services with translated titles and descriptions
  const serviceList: ServiceProps[] = [
    {
      title: t('services.cutAndGo'),
      description: t('services.cutAndGoDesc'),
      price: 32,
      duration: '30 min',
      image: 'https://images.unsplash.com/photo-1599351431613-18ef1fdd27e1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      alt: 'Barber cutting hair'
    },
    {
      title: t('services.beard'),
      description: t('services.beardDesc'),
      price: 23,
      duration: '20 min',
      image: 'https://images.unsplash.com/photo-1503951914875-452162b0f3f1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      alt: 'Beard grooming service'
    },
    {
      title: t('services.kids'),
      description: t('services.kidsDesc'),
      price: 20,
      duration: '20 min',
      image: 'https://images.unsplash.com/photo-1621605815971-fbc98d665033?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=600&q=80',
      alt: 'Kids haircut service in barber shop'
    }
  ];
  
  return (
    <section id="services" className="py-12 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold mb-2">{t('services.title')}</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {t('services.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {serviceList.map((service, index) => (
            <ServiceCard key={index} {...service} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;