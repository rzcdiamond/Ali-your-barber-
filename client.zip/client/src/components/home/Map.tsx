import React from 'react';
import { Button } from '@/components/ui/button';

const Map: React.FC = () => {
  // Grindelwald location coordinates
  const latitude = 46.6244;
  const longitude = 8.0344;
  const address = "DORFSTRASSE 129, 3818 GRINDELWALD, Switzerland";
  
  // Open in Google Maps
  const openGoogleMaps = () => {
    const url = `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
    window.open(url, '_blank');
  };
  
  // Open in Apple Maps (only works on iOS devices)
  const openAppleMaps = () => {
    const url = `maps://maps.apple.com/?q=${address}&ll=${latitude},${longitude}`;
    window.open(url, '_blank');
  };
  
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="aspect-video relative">
        {/* Using a static image of a barber shop */}
        <img 
          src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
          alt="Ali Your Barber shop location in Grindelwald"
          className="w-full h-full object-cover"
          onError={(e) => {
            // Fallback to another image if this one fails to load
            e.currentTarget.src = "https://images.unsplash.com/photo-1512690459411-b9245aed614b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80";
          }}
        />
        
        {/* Overlay with store name and address */}
        <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-60 text-white p-4">
          <h3 className="font-bold">Ali Your Barber</h3>
          <p className="text-sm">{address}</p>
        </div>
      </div>
      
      <div className="p-4">
        <h3 className="font-bold text-lg mb-2">Find Us</h3>
        <p className="mb-1">Ali Your Barber</p>
        <p className="mb-4">{address}</p>
        <p className="mb-4">
          <span className="font-semibold">Hours:</span> Mon-Fri 9am-7pm, Sat 9am-5pm
        </p>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Button onClick={openGoogleMaps} className="flex-1">
            Directions in Google Maps
          </Button>
          <Button onClick={openAppleMaps} variant="outline" className="flex-1">
            Open in Apple Maps
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Map;