import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

window.addEventListener('error', (event) => {
  console.error('Global error caught:', event.error);
});

try {
  const rootElement = document.getElementById("root");
  if (!rootElement) {
    throw new Error("Root element not found");
  }
  
  console.log("Rendering App component...");
  createRoot(rootElement).render(<App />);
  console.log("App component rendered successfully!");
} catch (error) {
  console.error('Error rendering application:', error);
}
