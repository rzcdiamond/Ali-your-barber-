import React, { useState } from 'react';
import Footer from '@/components/layout/Footer';
import Hero from '@/components/home/Hero';
import Services from '@/components/home/Services';
import BusinessHours from '@/components/home/BusinessHours';
import Map from '@/components/home/Map';
import Contact from '@/components/home/Contact';
import SimpleAppointments from '@/components/home/SimpleAppointments';
import QuickBookModal from '@/components/home/QuickBookModal';
import LanguageSelector from '@/components/layout/LanguageSelector';
import { useTranslation } from '@/lib/TranslationContext';
import { Link } from 'wouter';

const Home: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { t } = useTranslation();
  
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <div>
      {/* Basic navigation without auth context */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white text-gray-900 shadow-md py-2">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Link href="/" className="font-bold text-xl md:text-2xl cursor-pointer">
                Ali Your Barber
              </Link>
              <div className="flex items-center">
                <span className="text-sm text-gray-600 mr-1">{t('navigation.language')}:</span>
                <LanguageSelector />
              </div>
            </div>
            
            {/* Desktop menu */}
            <div className="hidden md:flex items-center space-x-6">
              <a 
                href="#services"
                className="hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('services');
                }}
              >
                {t('navigation.services')}
              </a>
              <a 
                href="#hours"
                className="hover:text-primary transition-colors" 
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('hours');
                }}
              >
                {t('navigation.hours')}
              </a>
              <a 
                href="#location"
                className="hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('location');
                }}
              >
                {t('navigation.location')}
              </a>
              <a 
                href="#contact"
                className="hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('contact');
                }}
              >
                {t('navigation.contact')}
              </a>
              <a 
                href={import.meta.env.VITE_CALENDLY_URL || "#appointments"}
                className="bg-primary text-white rounded-md px-4 py-2 hover:bg-primary/90 transition-colors"
                onClick={(e) => {
                  if (!import.meta.env.VITE_CALENDLY_URL) {
                    e.preventDefault();
                    scrollToSection('appointments');
                  }
                }}
                target={import.meta.env.VITE_CALENDLY_URL ? "_blank" : undefined}
                rel={import.meta.env.VITE_CALENDLY_URL ? "noopener noreferrer" : undefined}
              >
                {t('navigation.bookNow')}
              </a>
            </div>
            
            {/* Mobile menu button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className="p-2 focus:outline-none text-gray-900"
              >
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className="h-6 w-6" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                    strokeWidth={2} 
                    d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} 
                  />
                </svg>
              </button>
            </div>
          </div>
          
          {/* Mobile menu */}
          {isMobileMenuOpen && (
            <div className="md:hidden pt-4 pb-2 space-y-2">
              <div className="py-2 border-b border-gray-200 mb-2">
                <div className="flex items-center">
                  <span className="text-sm text-gray-600 mr-2">{t('navigation.language')}:</span>
                  <LanguageSelector />
                </div>
              </div>
              <a 
                href="#services"
                className="block py-2 hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('services');
                }}
              >
                {t('navigation.services')}
              </a>
              <a 
                href="#hours"
                className="block py-2 hover:text-primary transition-colors" 
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('hours');
                }}
              >
                {t('navigation.hours')}
              </a>
              <a 
                href="#location"
                className="block py-2 hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('location');
                }}
              >
                {t('navigation.location')}
              </a>
              <a 
                href="#contact"
                className="block py-2 hover:text-primary transition-colors"
                onClick={(e) => {
                  e.preventDefault();
                  scrollToSection('contact');
                }}
              >
                {t('navigation.contact')}
              </a>
              <a 
                href={import.meta.env.VITE_CALENDLY_URL || "#appointments"}
                className="block py-2 hover:text-primary transition-colors"
                onClick={(e) => {
                  if (!import.meta.env.VITE_CALENDLY_URL) {
                    e.preventDefault();
                    scrollToSection('appointments');
                  }
                  setIsMobileMenuOpen(false);
                }}
                target={import.meta.env.VITE_CALENDLY_URL ? "_blank" : undefined}
                rel={import.meta.env.VITE_CALENDLY_URL ? "noopener noreferrer" : undefined}
              >
                {t('navigation.bookNow')}
              </a>
            </div>
          )}
        </div>
      </nav>
      
      <main>
        {/* Hero Section */}
        <section id="home">
          <Hero />
        </section>
        
        {/* Services Section */}
        <section id="services">
          <Services />
        </section>
        
        {/* Business Hours Section */}
        <section id="hours">
          <BusinessHours />
        </section>
        
        {/* Appointments Section */}
        <section id="appointments">
          <SimpleAppointments />
        </section>
        
        {/* Map & Location Section */}
        <section id="location" className="py-12 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-10">
              <h2 className="text-3xl font-bold mb-2">{t('location.title')}</h2>
              <p className="text-gray-600 max-w-2xl mx-auto">
                {t('location.description')}
              </p>
            </div>
            
            <div className="max-w-xl mx-auto">
              <Map />
            </div>
          </div>
        </section>
        
        {/* Contact Section */}
        <section id="contact">
          <Contact />
        </section>
      </main>
      
      <Footer />
      
      {/* Quick Book Modal for Mobile */}
      <QuickBookModal />
    </div>
  );
};

export default Home;