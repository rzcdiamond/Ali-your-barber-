// Font utility functions
export const fonts = {
  heading: 'font-heading', // Playfair Display
  body: 'font-sans' // Poppins
};

// This helps with consistent styling across components
export const textStyles = {
  h1: `${fonts.heading} text-4xl md:text-5xl lg:text-6xl font-bold leading-tight`,
  h2: `${fonts.heading} text-3xl md:text-4xl font-bold`,
  h3: `${fonts.heading} text-2xl md:text-3xl font-bold`,
  h4: `${fonts.heading} text-xl font-bold`,
  body: `${fonts.body} text-base`,
  small: `${fonts.body} text-sm`
};
