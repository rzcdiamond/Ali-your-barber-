import React, { createContext, useContext, useState, useEffect } from 'react';
import { TranslationKey, getTranslation } from './translations';

interface TranslationContextType {
  currentLanguage: string;
  setLanguage: (lang: string) => void;
  t: (key: TranslationKey) => string;
}

const TranslationContext = createContext<TranslationContextType>({
  currentLanguage: 'en',
  setLanguage: () => {},
  t: (key: TranslationKey) => key,
});

export const useTranslation = () => useContext(TranslationContext);

interface TranslationProviderProps {
  children: React.ReactNode;
}

export const TranslationProvider: React.FC<TranslationProviderProps> = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState<string>('en');
  
  useEffect(() => {
    // Get language from local storage on initial load
    const savedLanguage = localStorage.getItem('userLanguage');
    if (savedLanguage) {
      setCurrentLanguage(savedLanguage);
    } else {
      // Try to detect browser language
      const browserLang = navigator.language.split('-')[0];
      // Check if browser language is supported
      if (['en', 'de', 'fr', 'it', 'es', 'pt', 'ar', 'ru', 'hi', 'zh', 'ja', 'ko'].includes(browserLang)) {
        setCurrentLanguage(browserLang);
        localStorage.setItem('userLanguage', browserLang);
      }
    }
  }, []);

  const setLanguage = (lang: string) => {
    setCurrentLanguage(lang);
    localStorage.setItem('userLanguage', lang);
  };

  const t = (key: TranslationKey): string => {
    return getTranslation(currentLanguage, key);
  };

  return (
    <TranslationContext.Provider value={{ currentLanguage, setLanguage, t }}>
      {children}
    </TranslationContext.Provider>
  );
};