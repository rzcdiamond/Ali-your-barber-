export type TranslationKey = 
  | 'navigation.services'
  | 'navigation.hours'
  | 'navigation.location'
  | 'navigation.contact'
  | 'navigation.bookNow'
  | 'navigation.language'
  | 'hero.title'
  | 'hero.subtitle'
  | 'hero.bookAppointment'
  | 'hero.ourServices'
  | 'hero.expertStylists'
  | 'hero.expertStylistsDesc'
  | 'hero.premiumCare'
  | 'hero.premiumCareDesc'
  | 'hero.easyBooking'
  | 'hero.easyBookingDesc'
  | 'services.title'
  | 'services.description'
  | 'services.cutAndGo'
  | 'services.cutAndGoDesc'
  | 'services.beard'
  | 'services.beardDesc'
  | 'services.kids'
  | 'services.kidsDesc'
  | 'services.bookService'
  | 'hours.title'
  | 'hours.subtitle'
  | 'hours.monday'
  | 'hours.tuesday'
  | 'hours.wednesday'
  | 'hours.thursday'
  | 'hours.friday'
  | 'hours.saturday'
  | 'hours.sunday'
  | 'hours.closed'
  | 'hours.holidayNotice'
  | 'hours.specialAppointments'
  | 'appointments.title'
  | 'appointments.description'
  | 'appointments.calendlyButton'
  | 'appointments.reminderNote'
  | 'appointments.reminderText'
  | 'appointments.rescheduleInfo'
  | 'location.title'
  | 'location.description'
  | 'contact.title'
  | 'contact.subtitle'
  | 'contact.phone'
  | 'contact.address'
  | 'contact.email'
  | 'contact.getInTouch'
  | 'footer.copyright';

export type Translations = {
  [key in TranslationKey]: string;
};

// English translations - default
export const en: Translations = {
  'navigation.services': 'Services',
  'navigation.hours': 'Hours',
  'navigation.location': 'Location',
  'navigation.contact': 'Contact',
  'navigation.bookNow': 'Book Now',
  'navigation.language': 'Language',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Professional haircuts and beard styling for the modern gentleman. Experience the perfect combination of traditional barbering with contemporary style.',
  'hero.bookAppointment': 'Book Appointment',
  'hero.ourServices': 'Our Services',
  'hero.expertStylists': 'Expert Stylists',
  'hero.expertStylistsDesc': 'Professional barbers with years of experience',
  'hero.premiumCare': 'Premium Care',
  'hero.premiumCareDesc': 'Quality products and attentive service',
  'hero.easyBooking': 'Easy Booking',
  'hero.easyBookingDesc': 'Online appointments with 24h reminders',
  'services.title': 'Our Services',
  'services.description': 'We offer a range of professional barbering services to keep you looking your best. All services include a consultation to ensure you get exactly what you want.',
  'services.cutAndGo': 'Cut & Go',
  'services.cutAndGoDesc': 'A quick and professional haircut service that includes washing, cutting, and styling.',
  'services.beard': 'Bart (Beard)',
  'services.beardDesc': 'Complete beard grooming service including trimming, shaping, and maintenance advice.',
  'services.kids': 'Kinder (Kids)',
  'services.kidsDesc': 'Child-friendly haircut service in a comfortable environment for young clients.',
  'services.bookService': 'Book this service',
  'hours.title': 'Business Hours',
  'hours.subtitle': 'Visit us during our business hours for walk-ins or book an appointment online.',
  'hours.monday': 'Monday',
  'hours.tuesday': 'Tuesday',
  'hours.wednesday': 'Wednesday',
  'hours.thursday': 'Thursday',
  'hours.friday': 'Friday',
  'hours.saturday': 'Saturday',
  'hours.sunday': 'Sunday',
  'hours.closed': 'Closed',
  'hours.holidayNotice': 'We are closed on public holidays.',
  'hours.specialAppointments': 'For early morning or late evening appointments, please call us directly.',
  'appointments.title': 'Book Your Appointment',
  'appointments.description': 'Choose a convenient time for your next visit using our online booking system.',
  'appointments.calendlyButton': 'Book a',
  'appointments.reminderNote': 'Note',
  'appointments.reminderText': 'We send email reminders 24 hours before your appointment.',
  'appointments.rescheduleInfo': 'Need to reschedule? You can manage your appointment through the confirmation email you\'ll receive.',
  'location.title': 'Location',
  'location.description': 'Find us in Grindelwald at DORFSTRASSE 129, easily accessible by public transport or car.',
  'contact.title': 'Contact Us',
  'contact.subtitle': 'Have questions? Get in touch with us directly.',
  'contact.phone': 'Phone',
  'contact.address': 'Address',
  'contact.email': 'Email',
  'contact.getInTouch': 'Get in Touch',
  'footer.copyright': '© 2023 Ali Your Barber. All rights reserved.'
};

// German translations
export const de: Translations = {
  'navigation.services': 'Dienstleistungen',
  'navigation.hours': 'Öffnungszeiten',
  'navigation.location': 'Standort',
  'navigation.contact': 'Kontakt',
  'navigation.bookNow': 'Jetzt buchen',
  'navigation.language': 'Sprache',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Professionelle Haarschnitte und Bartpflege für den modernen Gentleman. Erleben Sie die perfekte Kombination aus traditionellem Barbierhandwerk und zeitgemäßem Stil.',
  'hero.bookAppointment': 'Termin buchen',
  'hero.ourServices': 'Unsere Dienstleistungen',
  'hero.expertStylists': 'Experten-Stylisten',
  'hero.expertStylistsDesc': 'Professionelle Barbiere mit jahrelanger Erfahrung',
  'hero.premiumCare': 'Premium-Pflege',
  'hero.premiumCareDesc': 'Qualitätsprodukte und aufmerksamer Service',
  'hero.easyBooking': 'Einfache Buchung',
  'hero.easyBookingDesc': 'Online-Termine mit 24h Erinnerungen',
  'services.title': 'Unsere Dienstleistungen',
  'services.description': 'Wir bieten eine Reihe professioneller Barbier-Dienstleistungen an, damit Sie immer gut aussehen. Alle Dienstleistungen beinhalten eine Beratung, um sicherzustellen, dass Sie genau das bekommen, was Sie möchten.',
  'services.cutAndGo': 'Schneiden & Gehen',
  'services.cutAndGoDesc': 'Ein schneller und professioneller Haarschnitt-Service, der Waschen, Schneiden und Styling umfasst.',
  'services.beard': 'Bart',
  'services.beardDesc': 'Kompletter Bartpflege-Service einschließlich Trimmen, Formen und Pflegeberatung.',
  'services.kids': 'Kinder',
  'services.kidsDesc': 'Kinderfreundlicher Haarschnitt-Service in einer komfortablen Umgebung für junge Kunden.',
  'services.bookService': 'Diesen Service buchen',
  'hours.title': 'Geschäftszeiten',
  'hours.subtitle': 'Besuchen Sie uns während unserer Geschäftszeiten für Spontanbesuche oder buchen Sie einen Termin online.',
  'hours.monday': 'Montag',
  'hours.tuesday': 'Dienstag',
  'hours.wednesday': 'Mittwoch',
  'hours.thursday': 'Donnerstag',
  'hours.friday': 'Freitag',
  'hours.saturday': 'Samstag',
  'hours.sunday': 'Sonntag',
  'hours.closed': 'Geschlossen',
  'hours.holidayNotice': 'An Feiertagen geschlossen.',
  'hours.specialAppointments': 'Für frühe oder späte Termine rufen Sie uns bitte direkt an.',
  'appointments.title': 'Buchen Sie Ihren Termin',
  'appointments.description': 'Wählen Sie eine bequeme Zeit für Ihren nächsten Besuch mit unserem Online-Buchungssystem.',
  'appointments.calendlyButton': 'Buchen Sie einen',
  'appointments.reminderNote': 'Hinweis',
  'appointments.reminderText': 'Wir senden 24 Stunden vor Ihrem Termin E-Mail-Erinnerungen.',
  'appointments.rescheduleInfo': 'Termin verschieben? Sie können Ihren Termin über die Bestätigungs-E-Mail verwalten.',
  'location.title': 'Standort',
  'location.description': 'Finden Sie uns in Grindelwald an der DORFSTRASSE 129, leicht erreichbar mit öffentlichen Verkehrsmitteln oder dem Auto.',
  'contact.title': 'Kontaktieren Sie uns',
  'contact.subtitle': 'Haben Sie Fragen? Nehmen Sie direkt Kontakt mit uns auf.',
  'contact.phone': 'Telefon',
  'contact.address': 'Adresse',
  'contact.email': 'E-Mail',
  'contact.getInTouch': 'Kontakt aufnehmen',
  'footer.copyright': '© 2023 Ali Your Barber. Alle Rechte vorbehalten.'
};

// French translations
export const fr: Translations = {
  'navigation.services': 'Services',
  'navigation.hours': 'Horaires',
  'navigation.location': 'Emplacement',
  'navigation.contact': 'Contact',
  'navigation.bookNow': 'Réserver',
  'navigation.language': 'Langue',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Coupes de cheveux professionnelles et coiffage de barbe pour le gentleman moderne. Découvrez la combinaison parfaite entre barbier traditionnel et style contemporain.',
  'hero.bookAppointment': 'Prendre rendez-vous',
  'hero.ourServices': 'Nos services',
  'hero.expertStylists': 'Stylistes experts',
  'hero.expertStylistsDesc': 'Barbiers professionnels avec des années d\'expérience',
  'hero.premiumCare': 'Soins premium',
  'hero.premiumCareDesc': 'Produits de qualité et service attentif',
  'hero.easyBooking': 'Réservation facile',
  'hero.easyBookingDesc': 'Rendez-vous en ligne avec rappels 24h',
  'services.title': 'Nos services',
  'services.description': 'Nous offrons une gamme de services de barbier professionnels pour vous garder au meilleur de votre apparence. Tous les services comprennent une consultation pour s\'assurer que vous obtenez exactement ce que vous voulez.',
  'services.cutAndGo': 'Coupe rapide',
  'services.cutAndGoDesc': 'Un service de coupe de cheveux rapide et professionnel qui comprend le lavage, la coupe et le coiffage.',
  'services.beard': 'Barbe',
  'services.beardDesc': 'Service complet d\'entretien de la barbe comprenant la taille, la mise en forme et des conseils d\'entretien.',
  'services.kids': 'Enfants',
  'services.kidsDesc': 'Service de coupe de cheveux adapté aux enfants dans un environnement confortable pour les jeunes clients.',
  'services.bookService': 'Réserver ce service',
  'hours.title': 'Heures d\'ouverture',
  'hours.subtitle': 'Visitez-nous pendant nos heures d\'ouverture pour les visites sans rendez-vous ou réservez un rendez-vous en ligne.',
  'hours.monday': 'Lundi',
  'hours.tuesday': 'Mardi',
  'hours.wednesday': 'Mercredi',
  'hours.thursday': 'Jeudi',
  'hours.friday': 'Vendredi',
  'hours.saturday': 'Samedi',
  'hours.sunday': 'Dimanche',
  'hours.closed': 'Fermé',
  'hours.holidayNotice': 'Nous sommes fermés les jours fériés.',
  'hours.specialAppointments': 'Pour les rendez-vous tôt le matin ou tard le soir, veuillez nous appeler directement.',
  'appointments.title': 'Réservez votre rendez-vous',
  'appointments.description': 'Choisissez un moment pratique pour votre prochaine visite en utilisant notre système de réservation en ligne.',
  'appointments.calendlyButton': 'Réserver un',
  'appointments.reminderNote': 'Note',
  'appointments.reminderText': 'Nous envoyons des rappels par email 24 heures avant votre rendez-vous.',
  'appointments.rescheduleInfo': 'Besoin de reprogrammer? Vous pouvez gérer votre rendez-vous via l\'email de confirmation que vous recevrez.',
  'location.title': 'Emplacement',
  'location.description': 'Trouvez-nous à Grindelwald à DORFSTRASSE 129, facilement accessible en transports en commun ou en voiture.',
  'contact.title': 'Contactez-nous',
  'contact.subtitle': 'Vous avez des questions ? Contactez-nous directement.',
  'contact.phone': 'Téléphone',
  'contact.address': 'Adresse',
  'contact.email': 'Email',
  'contact.getInTouch': 'Prendre contact',
  'footer.copyright': '© 2023 Ali Your Barber. Tous droits réservés.'
};

// Italian translations
export const it: Translations = {
  'navigation.services': 'Servizi',
  'navigation.hours': 'Orari',
  'navigation.location': 'Posizione',
  'navigation.contact': 'Contatti',
  'navigation.bookNow': 'Prenota ora',
  'navigation.language': 'Lingua',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Tagli di capelli professionali e styling della barba per il gentiluomo moderno. Sperimenta la perfetta combinazione tra barbiere tradizionale e stile contemporaneo.',
  'hero.bookAppointment': 'Prenota appuntamento',
  'hero.ourServices': 'I nostri servizi',
  'hero.expertStylists': 'Stilisti esperti',
  'hero.expertStylistsDesc': 'Barbieri professionisti con anni di esperienza',
  'hero.premiumCare': 'Cura premium',
  'hero.premiumCareDesc': 'Prodotti di qualità e servizio attento',
  'hero.easyBooking': 'Prenotazione facile',
  'hero.easyBookingDesc': 'Appuntamenti online con promemoria 24h',
  'services.title': 'I nostri servizi',
  'services.description': 'Offriamo una gamma di servizi di barbiere professionali per mantenerti al meglio. Tutti i servizi includono una consulenza per assicurarti di ottenere esattamente ciò che desideri.',
  'services.cutAndGo': 'Taglio rapido',
  'services.cutAndGoDesc': 'Un servizio di taglio di capelli rapido e professionale che include lavaggio, taglio e styling.',
  'services.beard': 'Barba',
  'services.beardDesc': 'Servizio completo di cura della barba che include rifinitura, modellatura e consigli per la manutenzione.',
  'services.kids': 'Bambini',
  'services.kidsDesc': 'Servizio di taglio di capelli adatto ai bambini in un ambiente confortevole per i giovani clienti.',
  'services.bookService': 'Prenota questo servizio',
  'hours.title': 'Orari di apertura',
  'hours.subtitle': 'Visitaci durante i nostri orari di apertura per visite senza appuntamento o prenota un appuntamento online.',
  'hours.monday': 'Lunedì',
  'hours.tuesday': 'Martedì',
  'hours.wednesday': 'Mercoledì',
  'hours.thursday': 'Giovedì',
  'hours.friday': 'Venerdì',
  'hours.saturday': 'Sabato',
  'hours.sunday': 'Domenica',
  'hours.closed': 'Chiuso',
  'hours.holidayNotice': 'Siamo chiusi durante le festività pubbliche.',
  'hours.specialAppointments': 'Per appuntamenti la mattina presto o la sera tardi, chiamaci direttamente.',
  'appointments.title': 'Prenota il tuo appuntamento',
  'appointments.description': 'Scegli un orario conveniente per la tua prossima visita utilizzando il nostro sistema di prenotazione online.',
  'appointments.calendlyButton': 'Prenota un',
  'appointments.reminderNote': 'Nota',
  'appointments.reminderText': 'Inviamo promemoria via email 24 ore prima del tuo appuntamento.',
  'appointments.rescheduleInfo': 'Hai bisogno di riprogrammare? Puoi gestire il tuo appuntamento tramite l\'email di conferma che riceverai.',
  'location.title': 'Posizione',
  'location.description': 'Trovaci a Grindelwald in DORFSTRASSE 129, facilmente raggiungibile con i mezzi pubblici o in auto.',
  'contact.title': 'Contattaci',
  'contact.subtitle': 'Hai domande? Contattaci direttamente.',
  'contact.phone': 'Telefono',
  'contact.address': 'Indirizzo',
  'contact.email': 'Email',
  'contact.getInTouch': 'Mettiti in contatto',
  'footer.copyright': '© 2023 Ali Your Barber. Tutti i diritti riservati.'
};

// Spanish translations
export const es: Translations = {
  'navigation.services': 'Servicios',
  'navigation.hours': 'Horarios',
  'navigation.location': 'Ubicación',
  'navigation.contact': 'Contacto',
  'navigation.bookNow': 'Reservar ahora',
  'navigation.language': 'Idioma',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Cortes de pelo profesionales y estilismo de barba para el caballero moderno. Experimenta la combinación perfecta entre barbería tradicional y estilo contemporáneo.',
  'hero.bookAppointment': 'Reservar cita',
  'hero.ourServices': 'Nuestros servicios',
  'hero.expertStylists': 'Estilistas expertos',
  'hero.expertStylistsDesc': 'Barberos profesionales con años de experiencia',
  'hero.premiumCare': 'Cuidado premium',
  'hero.premiumCareDesc': 'Productos de calidad y servicio atento',
  'hero.easyBooking': 'Reserva fácil',
  'hero.easyBookingDesc': 'Citas en línea con recordatorios 24h',
  'services.title': 'Nuestros servicios',
  'services.description': 'Ofrecemos una gama de servicios de barbería profesionales para mantener tu mejor apariencia. Todos los servicios incluyen una consulta para asegurarnos de que obtengas exactamente lo que deseas.',
  'services.cutAndGo': 'Corte rápido',
  'services.cutAndGoDesc': 'Un servicio de corte de pelo rápido y profesional que incluye lavado, corte y peinado.',
  'services.beard': 'Barba',
  'services.beardDesc': 'Servicio completo de cuidado de barba que incluye recorte, modelado y consejos de mantenimiento.',
  'services.kids': 'Niños',
  'services.kidsDesc': 'Servicio de corte de pelo adaptado a niños en un ambiente cómodo para los clientes jóvenes.',
  'services.bookService': 'Reservar este servicio',
  'hours.title': 'Horario comercial',
  'hours.subtitle': 'Visítanos durante nuestro horario comercial sin cita previa o reserva una cita en línea.',
  'hours.monday': 'Lunes',
  'hours.tuesday': 'Martes',
  'hours.wednesday': 'Miércoles',
  'hours.thursday': 'Jueves',
  'hours.friday': 'Viernes',
  'hours.saturday': 'Sábado',
  'hours.sunday': 'Domingo',
  'hours.closed': 'Cerrado',
  'hours.holidayNotice': 'Permanecemos cerrados en días festivos.',
  'hours.specialAppointments': 'Para citas tempranas por la mañana o tardías por la noche, llámanos directamente.',
  'appointments.title': 'Reserva tu cita',
  'appointments.description': 'Elige un horario conveniente para tu próxima visita utilizando nuestro sistema de reservas en línea.',
  'appointments.calendlyButton': 'Reserva un',
  'appointments.reminderNote': 'Nota',
  'appointments.reminderText': 'Enviamos recordatorios por correo electrónico 24 horas antes de tu cita.',
  'appointments.rescheduleInfo': '¿Necesitas reprogramar? Puedes gestionar tu cita a través del correo de confirmación que recibirás.',
  'location.title': 'Ubicación',
  'location.description': 'Encuéntranos en Grindelwald en DORFSTRASSE 129, fácilmente accesible en transporte público o coche.',
  'contact.title': 'Contáctanos',
  'contact.subtitle': '¿Tienes preguntas? Ponte en contacto con nosotros directamente.',
  'contact.phone': 'Teléfono',
  'contact.address': 'Dirección',
  'contact.email': 'Correo electrónico',
  'contact.getInTouch': 'Ponerse en contacto',
  'footer.copyright': '© 2023 Ali Your Barber. Todos los derechos reservados.'
};

// Portuguese translations
export const pt: Translations = {
  'navigation.services': 'Serviços',
  'navigation.hours': 'Horários',
  'navigation.location': 'Localização',
  'navigation.contact': 'Contato',
  'navigation.bookNow': 'Agendar agora',
  'navigation.language': 'Idioma',
  'hero.title': 'Ali Your Barber',
  'hero.subtitle': 'Cortes de cabelo profissionais e estilização de barba para o cavalheiro moderno. Experimente a combinação perfeita de barbearia tradicional com estilo contemporâneo.',
  'hero.bookAppointment': 'Marcar consulta',
  'hero.ourServices': 'Nossos serviços',
  'hero.expertStylists': 'Estilistas especialistas',
  'hero.expertStylistsDesc': 'Barbeiros profissionais com anos de experiência',
  'hero.premiumCare': 'Cuidado premium',
  'hero.premiumCareDesc': 'Produtos de qualidade e serviço atencioso',
  'hero.easyBooking': 'Reserva fácil',
  'hero.easyBookingDesc': 'Agendamentos online com lembretes 24h',
  'services.title': 'Nossos serviços',
  'services.description': 'Oferecemos uma variedade de serviços de barbearia profissionais para mantê-lo com a melhor aparência. Todos os serviços incluem uma consulta para garantir que você obtenha exatamente o que deseja.',
  'services.cutAndGo': 'Corte rápido',
  'services.cutAndGoDesc': 'Um serviço de corte de cabelo rápido e profissional que inclui lavagem, corte e modelagem.',
  'services.beard': 'Barba',
  'services.beardDesc': 'Serviço completo de cuidados com a barba, incluindo aparar, modelar e conselhos de manutenção.',
  'services.kids': 'Crianças',
  'services.kidsDesc': 'Serviço de corte de cabelo adaptado para crianças em um ambiente confortável para clientes jovens.',
  'services.bookService': 'Reservar este serviço',
  'hours.title': 'Horário de funcionamento',
  'hours.subtitle': 'Visite-nos durante nosso horário comercial para atendimentos sem agendamento ou reserve um horário online.',
  'hours.monday': 'Segunda-feira',
  'hours.tuesday': 'Terça-feira',
  'hours.wednesday': 'Quarta-feira',
  'hours.thursday': 'Quinta-feira',
  'hours.friday': 'Sexta-feira',
  'hours.saturday': 'Sábado',
  'hours.sunday': 'Domingo',
  'hours.closed': 'Fechado',
  'hours.holidayNotice': 'Estamos fechados em feriados públicos.',
  'hours.specialAppointments': 'Para agendamentos no início da manhã ou no fim da noite, por favor ligue diretamente.',
  'appointments.title': 'Agende sua consulta',
  'appointments.description': 'Escolha um horário conveniente para sua próxima visita usando nosso sistema de agendamento online.',
  'appointments.calendlyButton': 'Agendar um',
  'appointments.reminderNote': 'Nota',
  'appointments.reminderText': 'Enviamos lembretes por e-mail 24 horas antes do seu agendamento.',
  'appointments.rescheduleInfo': 'Precisa reagendar? Você pode gerenciar seu agendamento através do email de confirmação que receberá.',
  'location.title': 'Localização',
  'location.description': 'Encontre-nos em Grindelwald na DORFSTRASSE 129, facilmente acessível por transporte público ou carro.',
  'contact.title': 'Contate-nos',
  'contact.subtitle': 'Tem perguntas? Entre em contato conosco diretamente.',
  'contact.phone': 'Telefone',
  'contact.address': 'Endereço',
  'contact.email': 'E-mail',
  'contact.getInTouch': 'Entrar em contato',
  'footer.copyright': '© 2023 Ali Your Barber. Todos os direitos reservados.'
};

// Add other language translations here (ar, ru, hi, zh, ja, ko)...

// Create a translations object with all languages
export const translations = {
  en,
  de,
  fr,
  it,
  es,
  pt,
  // Add more languages as you implement them
};

// Function to get a translation
export function getTranslation(lang: string, key: TranslationKey): string {
  const langTranslations = translations[lang as keyof typeof translations] || en;
  return langTranslations[key] || en[key];
}