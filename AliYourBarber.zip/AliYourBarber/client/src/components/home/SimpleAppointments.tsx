import React from 'react';
import { Button } from '@/components/ui/button';
import { useTranslation } from '@/lib/TranslationContext';

// Get Calendly URL from environment variable
const CALENDLY_URL = import.meta.env.VITE_CALENDLY_URL || '';

// For debug purposes
console.log('Calendly URL configured as:', CALENDLY_URL);

// Define services
interface ServiceType {
  name: string;
  displayName: string;
  price: number;
}

const SimpleAppointments: React.FC = () => {
  const { t } = useTranslation();
  
  // Create a direct link to Calendly with service name
  const getCalendlyLink = (service: string) => {
    if (!CALENDLY_URL) return '#';
    
    // Create a URL with parameters
    const url = new URL(CALENDLY_URL);
    
    // Add the service as a custom parameter
    url.searchParams.append('custom_question', 'Service Type');
    url.searchParams.append('custom_answer', service);
    
    console.log(`Generated Calendly link for ${service}:`, url.toString());
    return url.toString();
  };

  // Define translated services
  const translatedServices = [
    { name: 'Cut & Go', displayName: t('services.cutAndGo'), price: 32 },
    { name: 'Beard', displayName: t('services.beard'), price: 23 },
    { name: 'Kids', displayName: t('services.kids'), price: 20 }
  ];

  return (
    <section id="appointments" className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">{t('appointments.title')}</h2>
          <p className="text-gray-600 mb-8">
            {t('appointments.description')}
          </p>
          
          {!CALENDLY_URL ? (
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-8">
              <p className="text-yellow-800">
                Calendly URL is not configured. Please set up your Calendly integration to enable online bookings.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              {translatedServices.map((service) => (
                <a 
                  key={service.name}
                  href={getCalendlyLink(service.name)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-primary text-white rounded-md px-6 py-3 text-center hover:bg-primary/90 transition-colors block"
                >
                  {t('appointments.calendlyButton')} {service.displayName} ({service.price} CHF)
                </a>
              ))}
            </div>
          )}
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-600 mb-2">
              <span className="font-semibold">{t('appointments.reminderNote')}:</span> {t('appointments.reminderText')}
            </p>
            <p className="text-sm text-gray-600">
              {t('appointments.rescheduleInfo')}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SimpleAppointments;