const About = () => {
  return (
    <section id="about" className="py-16 bg-primary text-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6 font-heading">About Ali Your Barber</h2>
            <p className="mb-6 text-gray-300">
              At Ali Your Barber, we combine traditional barbering techniques with modern styles to give you the perfect look. Our skilled barbers are dedicated to providing exceptional service in a relaxed, welcoming environment.
            </p>
            <p className="mb-6 text-gray-300">
              With years of experience and a passion for our craft, we ensure every client leaves our shop looking and feeling their best. We take pride in our attention to detail and commitment to customer satisfaction.
            </p>
            <div className="flex flex-wrap gap-4 mt-8">
              <div className="bg-black bg-opacity-30 p-4 rounded-lg flex items-center">
                <i className="ri-scissors-2-line text-secondary text-2xl mr-3"></i>
                <div>
                  <h4 className="font-medium">Expert Barbers</h4>
                  <p className="text-sm text-gray-400">Skilled professionals</p>
                </div>
              </div>
              <div className="bg-black bg-opacity-30 p-4 rounded-lg flex items-center">
                <i className="ri-store-2-line text-secondary text-2xl mr-3"></i>
                <div>
                  <h4 className="font-medium">Premium Location</h4>
                  <p className="text-sm text-gray-400">Comfortable setting</p>
                </div>
              </div>
              <div className="bg-black bg-opacity-30 p-4 rounded-lg flex items-center">
                <i className="ri-customer-service-2-line text-secondary text-2xl mr-3"></i>
                <div>
                  <h4 className="font-medium">Quality Service</h4>
                  <p className="text-sm text-gray-400">Satisfaction guaranteed</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="rounded-lg overflow-hidden shadow-xl">
            <img 
              src="https://images.unsplash.com/photo-1585747860715-2ba37e788b70?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
              alt="Inside our barbershop" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
