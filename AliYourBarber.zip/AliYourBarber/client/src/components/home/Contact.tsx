import React from 'react';
import { Button } from '@/components/ui/button';

const Contact: React.FC = () => {
  const phoneNumber = '033 853 85 14'; // Updated phone number
  const email = 'info@aliyourbarber.ch'; // Example email
  const address = 'DORFSTRASSE 129, 3818 GRINDELWALD';
  
  const handlePhoneClick = () => {
    window.location.href = `tel:${phoneNumber.replace(/\s/g, '')}`;
  };
  
  const handleEmailClick = () => {
    window.location.href = `mailto:${email}`;
  };
  
  return (
    <section id="contact" className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold mb-2">Contact Us</h2>
            <p className="text-gray-600">
              Have questions or need to get in touch? We're here to help.
            </p>
          </div>
          
          <div className="bg-gray-50 rounded-lg shadow-md p-6 md:p-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="text-center md:text-left">
                <h3 className="text-xl font-bold mb-4">Contact Information</h3>
                <div className="space-y-3">
                  <p>
                    <span className="font-semibold block">Phone:</span>
                    {phoneNumber}
                  </p>
                  <p>
                    <span className="font-semibold block">Email:</span>
                    {email}
                  </p>
                  <p>
                    <span className="font-semibold block">Address:</span>
                    {address}
                  </p>
                  <div className="mt-6 space-y-2">
                    <Button onClick={handlePhoneClick} className="w-full md:w-auto">
                      Call Now
                    </Button>
                    <Button onClick={handleEmailClick} variant="outline" className="w-full md:w-auto">
                      Send Email
                    </Button>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-xl font-bold mb-4 text-center md:text-left">Quick Message</h3>
                <form className="space-y-4">
                  <div>
                    <input 
                      type="text" 
                      placeholder="Your Name" 
                      className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" 
                    />
                  </div>
                  <div>
                    <input 
                      type="email" 
                      placeholder="Your Email" 
                      className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary" 
                    />
                  </div>
                  <div>
                    <textarea 
                      placeholder="Your Message" 
                      rows={4} 
                      className="w-full p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                    ></textarea>
                  </div>
                  <Button type="submit" className="w-full">
                    Send Message
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;