import { Card, CardContent } from "@/components/ui/card";

interface TestimonialProps {
  quote: string;
  name: string;
  title: string;
  image: string;
}

const TestimonialCard = ({ quote, name, title, image }: TestimonialProps) => {
  return (
    <Card className="p-6">
      <CardContent className="p-0">
        <div className="flex items-center mb-4">
          <div className="text-secondary">
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
            <i className="ri-star-fill"></i>
          </div>
        </div>
        <p className="text-gray-600 mb-6">{quote}</p>
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-gray-300 mr-3 overflow-hidden">
            <img src={image} alt={name} className="w-full h-full object-cover" />
          </div>
          <div>
            <h4 className="font-medium">{name}</h4>
            <p className="text-sm text-gray-500">{title}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

const Testimonials = () => {
  const testimonials = [
    {
      quote: "The best haircut I've ever had. The barber took the time to understand exactly what I wanted and delivered perfectly. The atmosphere is great too!",
      name: "Marcus Johnson",
      title: "Regular client",
      image: "https://randomuser.me/api/portraits/men/32.jpg"
    },
    {
      quote: "I love that I can easily book online. The Calendly integration makes scheduling so easy, and I always get a reminder before my appointment. Great service!",
      name: "Thomas Weber",
      title: "Loyal customer",
      image: "https://randomuser.me/api/portraits/men/41.jpg"
    },
    {
      quote: "Brought my son for his first proper haircut and they were amazing with him. Patient, friendly, and did a fantastic job. We'll definitely be back!",
      name: "Sarah Mueller",
      title: "New customer",
      image: "https://randomuser.me/api/portraits/women/63.jpg"
    }
  ];

  return (
    <section className="py-16 bg-light">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 font-heading">What Our Clients Say</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">Don't just take our word for it. Here's what our satisfied customers have to say about their experience.</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <TestimonialCard key={index} {...testimonial} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
