import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { useAuth } from '@/App';
import { useToast } from '@/hooks/use-toast';

// Add type definition for Calendly
declare global {
  interface Window {
    Calendly?: any;
  }
}

// Get Calendly URL from environment variable or use a placeholder
const CALENDLY_URL = import.meta.env.VITE_CALENDLY_URL || '';

const Appointments: React.FC = () => {
  const [isCalendlyReady, setIsCalendlyReady] = useState(false);
  const { isAuthenticated, user, token } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  useEffect(() => {
    // Initialize Calendly
    const script = document.createElement('script');
    script.src = 'https://assets.calendly.com/assets/external/widget.js';
    script.async = true;
    
    script.onload = () => {
      setIsCalendlyReady(true);
    };
    
    document.body.appendChild(script);

    return () => {
      // Cleanup script on unmount
      document.body.removeChild(script);
    };
  }, []);

  // Creates an appointment record in our database
  const createAppointmentRecord = async (service: string, eventData: any) => {
    if (!isAuthenticated || !token) return;
    
    try {
      const appointmentData = {
        service,
        scheduledDate: eventData.start_time || new Date().toISOString(),
        calendlyEventId: eventData.uuid || '',
        calendlyUri: eventData.uri || ''
      };
      
      await fetch('/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(appointmentData)
      });
      
      toast({
        title: 'Appointment booked!',
        description: 'Your appointment has been scheduled and saved to your account.'
      });
    } catch (error) {
      console.error('Error saving appointment:', error);
    }
  };

  // Set up Calendly event listener
  useEffect(() => {
    function handleCalendlyEvent(e: any) {
      if (e.data.event && e.data.event.indexOf('calendly') === 0) {
        // Calendly event data
        const eventData = e.data.payload;
        
        if (e.data.event === 'calendly.event_scheduled') {
          // User has scheduled an event
          console.log('Calendly event scheduled:', eventData);
          
          // Extract service from question answers if available
          const service = eventData.questions_and_answers?.find(
            (qa: any) => qa.question === 'Service Type'
          )?.answer || 'Haircut';
          
          // Save appointment record if user is authenticated
          if (isAuthenticated) {
            createAppointmentRecord(service, eventData);
          } else {
            toast({
              title: 'Appointment booked!',
              description: 'Sign in or register to save this appointment to your account.',
              action: (
                <Button onClick={() => setLocation('/register')}>Register</Button>
              )
            });
          }
        }
      }
    }
    
    window.addEventListener('message', handleCalendlyEvent);
    
    return () => {
      window.removeEventListener('message', handleCalendlyEvent);
    };
  }, [isAuthenticated, token]);

  const openCalendly = (service: string) => {
    if (window.Calendly && CALENDLY_URL) {
      window.Calendly.initPopupWidget({
        url: CALENDLY_URL,
        prefill: {
          name: user?.fullName || '',
          email: user?.email || '',
          customAnswers: {
            a1: service
          }
        }
      });
    } else if (!CALENDLY_URL) {
      toast({
        title: 'Configuration Missing',
        description: 'Calendly URL is not configured. Please contact the administrator.',
        variant: 'destructive'
      });
    } else {
      // Fallback in case Calendly fails to load
      toast({
        title: 'Service Unavailable',
        description: 'Our booking system is currently unavailable. Please call us to schedule an appointment.',
        variant: 'destructive'
      });
    }
  };

  return (
    <section id="appointments" className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">Book an Appointment</h2>
          <p className="text-gray-600 mb-8">
            Schedule your appointment online and receive email reminders 24 hours before your visit. 
            Select the service you're interested in and choose a convenient time slot.
          </p>
          
          {!CALENDLY_URL ? (
            <div className="bg-yellow-50 border border-yellow-200 rounded-md p-4 mb-8">
              <p className="text-yellow-800">
                Calendly URL is not configured. Please set up your Calendly integration to enable online bookings.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
              <Button 
                onClick={() => openCalendly('Cut & Go')} 
                className="px-6 py-3"
                disabled={!isCalendlyReady}
              >
                {isCalendlyReady ? 'Book a Cut & Go (32 CHF)' : 'Loading...'}
              </Button>
              <Button 
                onClick={() => openCalendly('Bart')} 
                className="px-6 py-3"
                disabled={!isCalendlyReady}
              >
                {isCalendlyReady ? 'Book a Bart (23 CHF)' : 'Loading...'}
              </Button>
              <Button 
                onClick={() => openCalendly('Kinder')} 
                className="px-6 py-3"
                disabled={!isCalendlyReady}
              >
                {isCalendlyReady ? 'Book a Kinder (20 CHF)' : 'Loading...'}
              </Button>
            </div>
          )}
          
          <div className="bg-white p-4 rounded-lg shadow-md">
            <p className="text-sm text-gray-600 mb-2">
              <span className="font-semibold">Note:</span> We send email reminders 24 hours before your appointment.
            </p>
            <p className="text-sm text-gray-600">
              Need to reschedule? You can manage your appointment through the confirmation email you'll receive.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Appointments;