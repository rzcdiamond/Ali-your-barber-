import React, { useState } from 'react';
import { Button } from '@/components/ui/button';

interface QuestionOption {
  id: string;
  text: string;
  image?: string;
}

interface Question {
  id: string;
  text: string;
  options: QuestionOption[];
}

interface Stylist {
  id: string;
  name: string;
  specialty: string;
  experience: string;
  recommendation: string;
  image: string;
}

const questions: Question[] = [
  {
    id: 'hairType',
    text: 'What is your hair type?',
    options: [
      { id: 'straight', text: 'Straight' },
      { id: 'wavy', text: 'Wavy' },
      { id: 'curly', text: 'Curly' },
      { id: 'coily', text: 'Coily/Kinky' }
    ]
  },
  {
    id: 'hairLength',
    text: 'What is your current hair length?',
    options: [
      { id: 'short', text: 'Short (above ears)' },
      { id: 'medium', text: 'Medium (ear to shoulder)' },
      { id: 'long', text: 'Long (below shoulders)' }
    ]
  },
  {
    id: 'stylePreference',
    text: 'What style are you looking for?',
    options: [
      { id: 'classic', text: 'Classic/Traditional' },
      { id: 'modern', text: 'Modern/Trendy' },
      { id: 'low-maintenance', text: 'Low Maintenance' },
      { id: 'creative', text: 'Creative/Unique' }
    ]
  }
];

const stylists: Stylist[] = [
  {
    id: 'ali',
    name: 'Ali (Owner)',
    specialty: 'Classic cuts & precision fades',
    experience: '15+ years',
    recommendation: 'Perfect for traditional styles with modern touches',
    image: 'https://images.unsplash.com/photo-1622286342621-4bd786c2447c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'marco',
    name: 'Marco',
    specialty: 'Modern styles & creative designs',
    experience: '8 years',
    recommendation: 'Great for trendy cuts and artistic styling',
    image: 'https://images.unsplash.com/photo-1618499890638-3f8d5abd2e42?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
  },
  {
    id: 'sophia',
    name: 'Sophia',
    specialty: 'Curly hair & textured cuts',
    experience: '10 years',
    recommendation: 'Specialist in managing and styling curly/coily hair',
    image: 'https://images.unsplash.com/photo-1595273670150-bd0c3c392e46?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=200&q=80'
  }
];

// Simple recommendation logic based on answers
const getStylistRecommendation = (answers: Record<string, string>): Stylist => {
  // Default to Ali for most traditional/classic combinations
  if (answers.stylePreference === 'classic' || answers.stylePreference === 'low-maintenance') {
    return stylists[0]; // Ali
  }
  
  // Marco for trendy/creative styles especially with straight/wavy hair
  if (answers.stylePreference === 'modern' || answers.stylePreference === 'creative') {
    if (answers.hairType === 'straight' || answers.hairType === 'wavy') {
      return stylists[1]; // Marco
    }
  }
  
  // Sophia for curly/coily hair types
  if (answers.hairType === 'curly' || answers.hairType === 'coily') {
    return stylists[2]; // Sophia
  }
  
  // Fallback based on hair length
  if (answers.hairLength === 'long') {
    return stylists[2]; // Sophia is good with long hair
  }
  
  // Default recommendation
  return stylists[0]; // Ali (owner)
};

const StylistRecommendation: React.FC = () => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number | null>(null);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [recommendedStylist, setRecommendedStylist] = useState<Stylist | null>(null);
  
  const handleStart = () => {
    setCurrentQuestionIndex(0);
    setAnswers({});
    setRecommendedStylist(null);
  };
  
  const handleOptionSelect = (questionId: string, optionId: string) => {
    const newAnswers = { ...answers, [questionId]: optionId };
    setAnswers(newAnswers);
    
    if (currentQuestionIndex !== null && currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      // Last question answered, get recommendation
      const stylist = getStylistRecommendation(newAnswers);
      setRecommendedStylist(stylist);
      setCurrentQuestionIndex(null);
    }
  };
  
  const resetQuiz = () => {
    setCurrentQuestionIndex(null);
    setRecommendedStylist(null);
    setAnswers({});
  };

  // Initial state - show start button
  if (currentQuestionIndex === null && !recommendedStylist) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto my-8">
        <h2 className="text-2xl font-bold text-center mb-4">Find Your Perfect Stylist</h2>
        <p className="text-center mb-6">
          Answer a few questions and we'll recommend the best stylist for your hair type and style preferences.
        </p>
        <div className="flex justify-center">
          <Button onClick={handleStart} className="px-6 py-2">
            Start Quiz
          </Button>
        </div>
      </div>
    );
  }

  // Show current question
  if (currentQuestionIndex !== null && currentQuestionIndex < questions.length) {
    const currentQuestion = questions[currentQuestionIndex];
    
    return (
      <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto my-8">
        <div className="mb-2 text-sm font-medium">
          Question {currentQuestionIndex + 1} of {questions.length}
        </div>
        <h2 className="text-xl font-bold mb-4">{currentQuestion.text}</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
          {currentQuestion.options.map((option) => (
            <button
              key={option.id}
              onClick={() => handleOptionSelect(currentQuestion.id, option.id)}
              className="border rounded-md p-4 hover:bg-slate-50 transition-colors text-left flex items-center"
            >
              {option.text}
            </button>
          ))}
        </div>
        <div className="flex justify-end">
          <Button variant="outline" onClick={resetQuiz} size="sm">
            Cancel
          </Button>
        </div>
      </div>
    );
  }

  // Show recommendation result
  if (recommendedStylist) {
    return (
      <div className="bg-white rounded-lg shadow-md p-6 max-w-2xl mx-auto my-8">
        <h2 className="text-2xl font-bold text-center mb-2">Your Recommended Stylist</h2>
        <div className="flex flex-col md:flex-row items-center gap-6 mt-4">
          <div className="w-32 h-32 rounded-full overflow-hidden flex-shrink-0">
            <img 
              src={recommendedStylist.image} 
              alt={recommendedStylist.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <h3 className="text-xl font-bold">{recommendedStylist.name}</h3>
            <p className="text-gray-600 mb-1"><strong>Specialty:</strong> {recommendedStylist.specialty}</p>
            <p className="text-gray-600 mb-1"><strong>Experience:</strong> {recommendedStylist.experience}</p>
            <p className="mb-4">{recommendedStylist.recommendation}</p>
            <div className="flex gap-3">
              <Button>Book with {recommendedStylist.name.split(' ')[0]}</Button>
              <Button variant="outline" onClick={resetQuiz}>
                Try Again
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  return null;
};

export default StylistRecommendation;