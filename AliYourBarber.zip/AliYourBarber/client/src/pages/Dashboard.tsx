import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { useAuth } from '@/App';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';

type Appointment = {
  id: number;
  service: string;
  scheduledDate: string;
  status: string;
  calendlyEventId: string;
  calendlyUri: string;
};

const Dashboard: React.FC = () => {
  const { user, token, logout, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState('upcoming');

  // Redirect if not authenticated
  if (!isAuthenticated) {
    setLocation('/login');
    return null;
  }

  // Fetch appointments
  const { data: appointmentsData, isLoading, isError, refetch } = useQuery({
    queryKey: ['/api/appointments'],
    queryFn: async () => {
      const response = await fetch('/api/appointments', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch appointments');
      }
      
      const data = await response.json();
      return data.appointments;
    },
  });

  // Filter appointments by status
  const filterAppointments = (appointments: Appointment[] = []) => {
    if (activeTab === 'upcoming') {
      return appointments.filter(apt => 
        apt.status === 'scheduled' || apt.status === 'confirmed'
      );
    } else if (activeTab === 'past') {
      return appointments.filter(apt => 
        apt.status === 'completed' || apt.status === 'cancelled'
      );
    }
    return appointments;
  };

  // Cancel appointment
  const cancelAppointment = async (id: number) => {
    try {
      const response = await fetch(`/api/appointments/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: 'cancelled' }),
      });
      
      if (response.ok) {
        // Refresh appointments list
        refetch();
      }
    } catch (error) {
      console.error('Error cancelling appointment:', error);
    }
  };

  // Format date
  const formatAppointmentDate = (dateString: string) => {
    const date = new Date(dateString);
    return format(date, 'PPP p'); // e.g., 'April 29, 2023 at 12:30 PM'
  };
  
  // Get badge color based on status
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case 'scheduled':
        return 'bg-blue-100 text-blue-800';
      case 'confirmed':
        return 'bg-green-100 text-green-800';
      case 'completed':
        return 'bg-purple-100 text-purple-800';
      case 'cancelled':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };
  
  const filteredAppointments = appointmentsData ? filterAppointments(appointmentsData) : [];
  
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">My Dashboard</h1>
          <p className="text-gray-600">Welcome back, {user?.fullName || user?.username}</p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Profile Info</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div>
                  <span className="text-sm font-medium text-gray-500">Username:</span>
                  <p>{user?.username}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Email:</span>
                  <p>{user?.email || 'Not provided'}</p>
                </div>
                <div>
                  <span className="text-sm font-medium text-gray-500">Phone:</span>
                  <p>{user?.phone || 'Not provided'}</p>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={() => setLocation('/')}
                className="w-full"
              >
                Book New Appointment
              </Button>
              <Button 
                variant="outline" 
                onClick={logout}
                className="w-full"
              >
                Sign Out
              </Button>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Appointment Stats</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 p-3 rounded-lg text-center">
                  <p className="text-2xl font-bold text-blue-600">
                    {appointmentsData?.filter(a => a.status === 'scheduled' || a.status === 'confirmed').length || 0}
                  </p>
                  <p className="text-sm text-blue-700">Upcoming</p>
                </div>
                <div className="bg-purple-50 p-3 rounded-lg text-center">
                  <p className="text-2xl font-bold text-purple-600">
                    {appointmentsData?.filter(a => a.status === 'completed').length || 0}
                  </p>
                  <p className="text-sm text-purple-700">Completed</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <h2 className="text-2xl font-bold mb-4">My Appointments</h2>
          
          <Tabs defaultValue="upcoming" onValueChange={setActiveTab}>
            <TabsList className="mb-4">
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>
            
            <TabsContent value="upcoming" className="space-y-4">
              {isLoading ? (
                <p>Loading appointments...</p>
              ) : isError ? (
                <div className="bg-red-50 text-red-800 p-4 rounded-md">
                  Failed to load appointments. Please try again.
                </div>
              ) : filteredAppointments.length === 0 ? (
                <div className="bg-gray-50 p-8 text-center rounded-md">
                  <p className="text-gray-600">You have no upcoming appointments.</p>
                  <Button 
                    onClick={() => setLocation('/')} 
                    className="mt-4"
                  >
                    Book an Appointment
                  </Button>
                </div>
              ) : (
                filteredAppointments.map((appointment) => (
                  <Card key={appointment.id} className="overflow-hidden">
                    <div className="border-l-4 border-primary h-full">
                      <div className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="text-lg font-semibold">{appointment.service}</h3>
                            <p className="text-gray-600">{formatAppointmentDate(appointment.scheduledDate)}</p>
                          </div>
                          <Badge className={getStatusBadgeColor(appointment.status)}>
                            {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                          </Badge>
                        </div>
                        {appointment.status === 'scheduled' && (
                          <div className="mt-4">
                            <Button
                              variant="outline"
                              className="text-red-600 border-red-200 hover:bg-red-50"
                              onClick={() => cancelAppointment(appointment.id)}
                            >
                              Cancel Appointment
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </TabsContent>
            
            <TabsContent value="past" className="space-y-4">
              {isLoading ? (
                <p>Loading appointments...</p>
              ) : isError ? (
                <div className="bg-red-50 text-red-800 p-4 rounded-md">
                  Failed to load appointments. Please try again.
                </div>
              ) : filteredAppointments.length === 0 ? (
                <div className="bg-gray-50 p-8 text-center rounded-md">
                  <p className="text-gray-600">You have no past appointments.</p>
                </div>
              ) : (
                filteredAppointments.map((appointment) => (
                  <Card key={appointment.id} className="overflow-hidden">
                    <div className="border-l-4 border-gray-300 h-full">
                      <div className="p-6">
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-lg font-semibold">{appointment.service}</h3>
                            <p className="text-gray-600">{formatAppointmentDate(appointment.scheduledDate)}</p>
                          </div>
                          <Badge className={getStatusBadgeColor(appointment.status)}>
                            {appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <Footer />
    </div>
  );
};

export default Dashboard;