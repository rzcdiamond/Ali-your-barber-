import React from "react";
import { Route, Switch } from "wouter";
import Home from "@/pages/Home";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import { TranslationProvider } from "@/lib/TranslationContext";

// Main App component - simplified for public access only
function App() {
  console.log("Rendering App component...");
  
  return (
    <QueryClientProvider client={queryClient}>
      <TranslationProvider>
        <div className="app-root">
          <Switch>
            <Route path="/" component={Home} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </div>
      </TranslationProvider>
    </QueryClientProvider>
  );
}

export default App;
