import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertAppointmentSchema } from "@shared/schema";
import bcrypt from "bcryptjs";
import * as crypto from "crypto";

// Simple session storage (in a real app, use a proper session store)
const sessions = new Map<string, { userId: number, username: string, expires: number }>();

// Helper to generate session token
const generateSessionToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Middleware to check authentication
const authenticate = async (req: Request, res: Response, next: Function) => {
  const sessionToken = req.headers.authorization?.split(' ')[1];
  
  if (!sessionToken || !sessions.has(sessionToken)) {
    return res.status(401).json({ message: 'Unauthorized: Please log in' });
  }
  
  const session = sessions.get(sessionToken);
  
  // Check if session expired
  if (session && session.expires < Date.now()) {
    sessions.delete(sessionToken);
    return res.status(401).json({ message: 'Session expired: Please log in again' });
  }
  
  // Attach user info to request
  (req as any).user = {
    id: session?.userId,
    username: session?.username
  };
  
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Barber shop API is running' });
  });

  // User registration
  app.post('/api/register', async (req, res) => {
    try {
      const userInput = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByUsername(userInput.username);
      if (existingUser) {
        return res.status(409).json({ message: 'Username already exists' });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userInput.password, 10);
      
      // Create user with hashed password
      const newUser = await storage.createUser({
        ...userInput,
        password: hashedPassword
      });
      
      // Don't return password in response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json({
        message: 'User registered successfully',
        user: userWithoutPassword
      });
    } catch (error: any) {
      res.status(400).json({ message: 'Invalid registration data', error: error.message });
    }
  });

  // User login
  app.post('/api/login', async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ message: 'Username and password are required' });
      }
      
      // Find user
      const user = await storage.getUserByUsername(username);
      if (!user) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      // Check password
      const passwordValid = await bcrypt.compare(password, user.password);
      if (!passwordValid) {
        return res.status(401).json({ message: 'Invalid username or password' });
      }
      
      // Create session
      const token = generateSessionToken();
      const expiresIn = 7 * 24 * 60 * 60 * 1000; // 7 days in milliseconds
      
      sessions.set(token, {
        userId: user.id,
        username: user.username,
        expires: Date.now() + expiresIn
      });
      
      // Don't return password in response
      const { password: _, ...userWithoutPassword } = user;
      
      res.json({
        message: 'Login successful',
        token,
        user: userWithoutPassword
      });
    } catch (error: any) {
      res.status(500).json({ message: 'Login failed', error: error.message });
    }
  });

  // Get current user
  app.get('/api/me', authenticate, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
      
      // Don't return password
      const { password, ...userWithoutPassword } = user;
      
      res.json({ user: userWithoutPassword });
    } catch (error: any) {
      res.status(500).json({ message: 'Error fetching user data', error: error.message });
    }
  });

  // Logout
  app.post('/api/logout', (req, res) => {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (token) {
      sessions.delete(token);
    }
    
    res.json({ message: 'Logged out successfully' });
  });

  // Create an appointment
  app.post('/api/appointments', authenticate, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        userId
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      
      res.status(201).json({
        message: 'Appointment created successfully',
        appointment
      });
    } catch (error: any) {
      res.status(400).json({ message: 'Invalid appointment data', error: error.message });
    }
  });

  // Get user's appointments
  app.get('/api/appointments', authenticate, async (req, res) => {
    try {
      const userId = (req as any).user.id;
      const appointments = await storage.getAppointmentsByUserId(userId);
      
      res.json({ appointments });
    } catch (error: any) {
      res.status(500).json({ message: 'Error fetching appointments', error: error.message });
    }
  });

  // Update appointment status
  app.patch('/api/appointments/:id/status', authenticate, async (req, res) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ message: 'Status is required' });
      }
      
      // Verify appointment belongs to user
      const appointment = await storage.getAppointment(appointmentId);
      if (!appointment) {
        return res.status(404).json({ message: 'Appointment not found' });
      }
      
      if (appointment.userId !== (req as any).user.id) {
        return res.status(403).json({ message: 'You do not have permission to update this appointment' });
      }
      
      const updatedAppointment = await storage.updateAppointmentStatus(appointmentId, status);
      
      res.json({
        message: 'Appointment status updated',
        appointment: updatedAppointment
      });
    } catch (error: any) {
      res.status(500).json({ message: 'Error updating appointment', error: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
